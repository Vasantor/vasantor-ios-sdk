//
//  Vasantor.h
//  Vasantor
//
//  Created by Newroz Tech on 21/9/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Vasantor.
FOUNDATION_EXPORT double VasantorVersionNumber;

//! Project version string for Vasantor.
FOUNDATION_EXPORT const unsigned char VasantorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Vasantor/PublicHeader.h>


